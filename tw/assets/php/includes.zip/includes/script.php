<script language="JavaScript" type="text/JavaScript">
function ventana(url,nom){
var varurl=url;
var varnom=nom;
window.open(url,nom,'width=650,height=300');
}
function ventanascroll(url,nom){
var varurl=url;
var varnom=nom;
window.open(url,nom,'scrollbars=yes,width=800,height=600');
}
</script>

