<?php
$db = new sql_db($dbhost, $dbuname, $dbpass, $dbname, false);
if(!$db->db_connect_id) {
    die("<br><br><center><img src=images/logo.gif><br><br><b>There seems to be a problem with the MySQL server, sorry for the inconvenience.<br><br>We should be back shortly.</center></b>");
}
mysqli_query("SET NAMES 'utf8'");
?>