<?php
//$dbhost="rebosos.db.12600570.hostedresource.com";$dbuname="rebosos";$dbpass="delSur%01";$dbname="rebosos";$prefix="main";
//$dbhost="localhost";$dbuname="facturas_fuscoa3";$dbpass="s6XyNF;b)ol;";$dbname="facturas_fuscoa3";$prefix="main";


//$dbhost="localhost"; $dbuname="thinkweb_pv1"; $dbpass="ntiK-;+,#*.%"; $dbname="thinkweb_lacanada"; $prefix="main";

$dbhost="localhost";$dbuname="thinkweb_usuario";$dbpass="#ThinkwebUser2018@";$dbname="erp_comanorsa";$prefix="main";
//$dbhost="localhost";$dbuname="viboradelamarcom_shopweb";$dbpass="Nr4=X=-6Bze8";$dbname="viboradelamarcom_shopweb";$prefix="main";

$match=array('<','>','&','"','\'','¨');
$replace=array('&lt;','&gt;','&amp;','&quot;','&apos;','&quot;'); 
//$idcliente=124;

?>